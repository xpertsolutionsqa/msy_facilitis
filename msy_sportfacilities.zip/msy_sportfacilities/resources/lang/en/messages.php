<?php

return [

    "Jan"  => "Jan",
    "Feb"  => "Feb",
    "March" => "March",
    "Apr"  => "Apr",
    "May"  => "May",
    "Jun"  => "Jun",
    "July" => "July",
    "Aug"  => "Aug",
    "Sep"  => "Sep",
    "Oct"  => "Oct",
    "Nov"  => "Nov",
    "Dec"  => "Dec",
    "One day" => "One day",
    "Two Days" => "Two Days",
    "Days" => "Days",
    "morethan10Days" => "Days",
    // "booking_status_changed" => "booking status changed",
    // "booking_comment_added" => "booking comment added",
];
