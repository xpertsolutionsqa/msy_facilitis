<footer class="iq-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6">
              
            </div>
            <div class="col-lg-6 text-right">
                <a href="https://www.msy.gov.qa/" class="">{{__("MSY")}}</a>
                <span class="mr-1">
                    <script>
                        document.write(new Date().getFullYear())
                    </script>©
                </span> 
            </div>
        </div>
    </div>
</footer>