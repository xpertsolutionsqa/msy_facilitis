
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="iq-top-navbar-<?php echo e(app()->getLocale()); ?>">
           <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <h3><?php echo e(__('Attachments')); ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="card col-md-12 p-2">
                        <table class="table rounded">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th><?php echo e(__('Name')); ?></th>
                                    <th><?php echo e(__('Accept')); ?></th>
                                    <th><?php echo e(__('Max')); ?></th>
                                    <th><?php echo e(__('Required')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = \App\Models\Attachment::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i + 1); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td>
                                            <?php
                                                $types = explode(',', $item->accept);
                                            ?>
                                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="border badge text-primary border-primary"><?php echo e(substr($type, 1)); ?>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e($item->max); ?></td>
                                        <td> <input type="checkbox" <?php echo e($item->required == '1' ? 'checked' : ''); ?>

                                                class="changeReq smallcheck form-control" data-id="<?php echo e($item->id); ?>">
                                        </td>
                                        <td>
                                            <form class="d-inline"
                                                action="<?php echo e($item->status == '1' ? route('attachment.disable') : route('attachment.enable')); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                                <button type="submit"
                                                    class="btn <?php echo e($item->status == '1' ? 'btn-outline-warning' : 'btn-outline-success'); ?>">
                                                    <?php echo e($item->status == '1' ? __('Disable') : __('Enable')); ?>

                                                    <?php if($item->status == '1'): ?>
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                            width="24" height="24" fill="currentColor">
                                                            <path
                                                                d="M12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20ZM12 10.5858L14.8284 7.75736L16.2426 9.17157L13.4142 12L16.2426 14.8284L14.8284 16.2426L12 13.4142L9.17157 16.2426L7.75736 14.8284L10.5858 12L7.75736 9.17157L9.17157 7.75736L12 10.5858Z">
                                                            </path>
                                                        </svg>
                                                    <?php else: ?>
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                            width="24" height="24" fill="currentColor">
                                                            <path
                                                                d="M12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20ZM11.0026 16L6.75999 11.7574L8.17421 10.3431L11.0026 13.1716L16.6595 7.51472L18.0737 8.92893L11.0026 16Z">
                                                            </path>
                                                        </svg>
                                                    <?php endif; ?>
                                                </button>
                                                <button data-toggle-extra="tab" data-target="#edit_attach_model"
                                                    data-toggle="modal" type="button"
                                                    class="btn btn-outline-success EditAttach "
                                                    accept="<?php echo e($item->accept); ?>" max="<?php echo e($item->max); ?>"
                                                    arname="<?php echo e($item->getTranslation('name', 'ar')); ?>"
                                                    enname="<?php echo e($item->getTranslation('name', 'en')); ?>"
                                                    id="<?php echo e($item->id); ?>"><?php echo e(__('Edit')); ?></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <tr>
                                    <form action="<?php echo e(route('settings.attachemnts.save')); ?>" method="post">

                                        <?php echo csrf_field(); ?>
                                        <td>+</td>
                                        <td>
                                            <input required class="required form-control m-2" name="arname"
                                                placeholder="<?php echo e(__('Ar Name')); ?> *" type="text">
                                            <input required class="required form-control m-2" name="enname"
                                                placeholder="<?php echo e(__('En Name')); ?> *" type="text">
                                        </td>
                                        <td>
                                            <select class="form-control select2" required multiple name="accept[]">
                                                <option disabled><?php echo e(__('Type')); ?></option>
                                                <option value=".png">png</option>
                                                <option value=".jpg">jpg</option>
                                                <option value=".jpeg">jpeg</option>
                                                <option value=".pdf">pdf</option>
                                                <option value=".docx">docx</option>
                                                <option value=".doc">doc</option>
                                                <option value=".ppt">ppt</option>
                                                <option value=".xlsx">xlsx</option>
                                                <option value=".xls">xls</option>
                                                <option value=".mp4">mp4</option>
                                                <option value=".rar">rar</option>
                                                <option value=".zip">zip</option>
                                            </select>
                                        </td>
                                        <td><input required class="required form-control"
                                                placeholder="<?php echo e(__('Max')); ?> *   MB" type="number" name="max"
                                                min="1" id=""></td>
                                        <td><input class="required form-control smallcheck" type="checkbox" name="required"
                                                min="1" id=""></td>
                                        <td> <button type="submit"
                                                class="btn btn-outline-success"><?php echo e(__('Add')); ?></button> </td>
                                    </form>
                                </tr>
                            </tbody>

                        </table>


                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="modal fade bd-example-modal-lg" role="dialog" aria-modal="true" id="edit_attach_model" tabindex="-1">
        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header d-block text-center pb-3 border-bttom">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title"><?php echo e(__('Edit Attachment')); ?> </h3>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('attachment.update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" id="attachid">
                        <div class="row">
                            <div class="col-md-6">
                                <label for=""><?php echo e(__('Ar Name')); ?></label>
                                <input type="text" class="form-control" name="arname" required id="attacharname">
                            </div>
                            <div class="col-md-6">
                                <label for=""><?php echo e(__('En Name')); ?></label>
                                <input type="text" class="form-control" name="enname" required id="attachenname">
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for=""><?php echo e(__('Max')); ?></label>
                                <input type="number" class="form-control" class="form-control" name="max" required
                                    id="attachmax">
                            </div>
                            <div class="col-md-6">
                                <label for=""><?php echo e(__('Accept')); ?></label>
                                <select class="form-control  " required multiple name="accept[]" id="attachaccept">
                                    <option><?php echo e(__('Type')); ?></option>
                                    <option value=".png">png</option>
                                    <option value=".jpg">jpg</option>
                                    <option value=".jpeg">jpeg</option>
                                    <option value=".pdf">pdf</option>
                                    <option value=".docx">docx</option>
                                    <option value=".doc">doc</option>
                                    <option value=".ppt">ppt</option>
                                    <option value=".xlsx">xlsx</option>
                                    <option value=".xls">xls</option>
                                    <option value=".mp4">mp4</option>
                                    <option value=".rar">rar</option>
                                    <option value=".zip">zip</option>
                                </select>

                            </div>
                        </div>
                        <button type="submit" class="btn btn-block btn-outline-success"><?php echo e(__("Edit")); ?></button>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views/pages/attachments.blade.php ENDPATH**/ ?>