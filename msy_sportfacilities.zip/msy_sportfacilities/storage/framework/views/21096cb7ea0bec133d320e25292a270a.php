
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="iq-top-navbar-<?php echo e(app()->getLocale()); ?>">
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">

                                <h3><?php echo e(__('Notification')); ?></h3>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="row">
                                <div class="col-xl-12">


                                    <div class="shadow-bottom p-2">
                                        <form action="<?php echo e(route('settings.notification.save')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="row  d-flex align-items-center">
                                                <div class="col-md-2">
                                                    <div
                                                        class="custom-control custom-switch custom-switch-text custom-control-inline">
                                                        <div class="custom-switch-inner">
                                                            <p class="mb-0"> <?php echo e(__('Email Notification')); ?> </p>
                                                            <input name="email_enabled" type="checkbox"
                                                                class="custom-control-input" id="customSwitch-11"
                                                                <?php echo e($email_enabled == 'on' ? 'checked' : ''); ?>>
                                                            <label class="custom-control-label" for="customSwitch-11"
                                                                data-on-label="On" data-off-label="Off">
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <label> <?php echo e(__('Email Host')); ?> </label>

                                                    <input class="form-control" type="text" name="email_host"
                                                        id="" value="<?php echo e($email_host); ?>">
                                                </div>
                                                <div class="col-md-2">
                                                    <label> <?php echo e(__('Email Port')); ?> </label>

                                                    <input class="form-control" type="text" name="email_port"
                                                        id="" value="<?php echo e($email_port); ?>">
                                                </div>
                                                <div class="col-md-2">
                                                    <label> <?php echo e(__('Email From')); ?> </label>

                                                    <input class="form-control" type="email" name="email_fromaddress"
                                                        id="" value="<?php echo e($email_fromaddress); ?>">
                                                </div>
                                                <div class="col-md-2">
                                                    <label> <?php echo e(__('Email Username')); ?> </label>

                                                    <input class="form-control" type="text" name="email_smtp_username"
                                                        id="" value="<?php echo e($email_smtp_username); ?>">
                                                </div>
                                                <div class="col-md-2">
                                                    <label> <?php echo e(__('Email Password')); ?> </label>

                                                    <input class="form-control" type="text" name="email_smtp_password"
                                                        id="" value="<?php echo e($email_smtp_password); ?>">
                                                </div>

                                            </div>
                                            <div class="row p-3">
                                                <div class="col-md-12">
                                                    <button type="submit"
                                                        class="btn btn-block btn-outline-success"><?php echo e(__('Update')); ?></button>
                                                </div>
                                            </div>
                                        </form>



                                        <div class="row">
                                            
                                            <div class="col-md-4"><input class="form-control" type="email" id="testmail">
                                            </div>
                                            <div class="col-md-4">
                                                <select class="form-control" id="testmaillocale">

                                                    <option selected value="ar">Ar</option>
                                                    <option value="en">En</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4"><button type="button" id="TestMailBtn"
                                                    class="btn btn-block btn-outline-primary"><?php echo e(__('Send Test Email')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row p-5">
                                        <div class="col-md-10">
                                            <h3><?php echo e(__('Templates')); ?></h3>
                                        </div>
                                        <div class="col-md-2">
                                            <select class="form-control" id="TemplateSelector">
                                                <option value=""><?php echo e(__('Please Select')); ?></option>
                                                <option value="new_client"><?php echo e(__('messages.New Client Created')); ?>

                                                </option>
                                                <option value="reset_password">
                                                    <?php echo e(__('messages.Client Password Rested')); ?></option>
                                                <option value="new_booking"><?php echo e(__('messages.New Booking Created')); ?>

                                                </option>
                                                <option value="booking_approved">
                                                    <?php echo e(__('messages.Booking Status Approved')); ?></option>
                                                <option value="booking_returned">
                                                    <?php echo e(__('messages.Booking Returend For Edit')); ?></option>
                                                <option value="booking_rejected">
                                                    <?php echo e(__('messages.Booking Status Rejected')); ?></option>
                                                <option value="booking_status_changed">
                                                    <?php echo e(__('messages.booking_status_changed')); ?></option>
                                                <option value="booking_comment_added">
                                                    <?php echo e(__('messages.booking_comment_added')); ?></option>
                                                <option value="booking_edited">
                                                    <?php echo e(__('messages.booking_edited')); ?></option>
                                                 
                                                
                                                

                                            </select>
                                        </div>

                                    </div>

                                    <div class="row  ">
                                        <div class="col-md-12">
                                            <div id="TemplateDetails">
                                                <div class="p-3 text-center">
                                                    <p><?php echo e(__('Please Select Template')); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>




                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views\pages\notification.blade.php ENDPATH**/ ?>