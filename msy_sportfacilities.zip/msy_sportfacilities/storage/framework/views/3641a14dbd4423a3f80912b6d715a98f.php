

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="iq-top-navbar-<?php echo e(app()->getLocale()); ?>">
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card blur-shadow">
                            <div class="card-body">
                                <div class="d-flex flex-wrap align-items-center justify-content-between breadcrumb-content">
                                    <h5><?php echo e(__('Maintenance')); ?></h5>
                                    <div class="col-md-4">
                                        <?php if((auth()->check() && auth()->user()->level != 3) || auth()->guard('client')->check()): ?>
                                            <select id="FacilityFilter" name="facility" class="form-control select2">
                                                <option value=""><?php echo e(__('All Facilities')); ?> </option>
                                                <?php $__currentLoopData = \App\Models\Facility::where('status', '1')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        <?php echo e(app('request')->input('fa') == $item->number ? 'selected' : ''); ?>

                                                        value="<?php echo e($item->number); ?>"><?php echo e($item->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>

                                    </div>
                                    <div class="d-flex align-items-center">
                                        <div class="list-grid-toggle d-flex align-items-center mr-3">
                                            <div data-toggle-extra="tab" data-target-extra="#grid"
                                                class=" <?php echo e($gridactive); ?>">
                                                <div class="grid-icon p-2">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                        width="24" height="24" fill="currentColor">
                                                        <path
                                                            d="M17 3H21C21.5523 3 22 3.44772 22 4V20C22 20.5523 21.5523 21 21 21H3C2.44772 21 2 20.5523 2 20V4C2 3.44772 2.44772 3 3 3H7V1H9V3H15V1H17V3ZM4 9V19H20V9H4ZM6 11H8V13H6V11ZM6 15H8V17H6V15ZM10 11H18V13H10V11ZM10 15H15V17H10V15Z">
                                                        </path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div data-toggle-extra="tab" data-target-extra="#list"
                                                class="<?php echo e($listactive); ?>">
                                                <div class="grid-icon p-1">
                                                    <svg width="24" height="24" xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                        <line x1="21" y1="10" x2="3" y2="10">
                                                        </line>
                                                        <line x1="21" y1="6" x2="3" y2="6">
                                                        </line>
                                                        <line x1="21" y1="14" x2="3" y2="14">
                                                        </line>
                                                        <line x1="21" y1="18" x2="3" y2="18">
                                                        </line>
                                                    </svg>

                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="grid" class="item-content animate__animated animate__fadeIn  <?php echo e($gridactive); ?>"
                    data-toggle-extra="tab-content">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between shadow-bottom">
                            <div class="h6"> <?php echo e(__('Maintenance Calender')); ?></div>

                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-xl-8 shadow rounded h-100">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <a href="#" id="cal-prev"
                                            class="text-dark mr-2 font-size-18"><back-c-icon></a>
                                        <h5 class="mh-3" id="calender_title"> </h5>
                                        <div class="mt-1">

                                            <a href="#" id="cal-next"
                                                class="text-dark font-size-18"><front-c-icon></a>
                                        </div>
                                    </div>
                                    <div id="maintenancecalendar"></div>
                                </div>
                                <div class="col-md-4 " id="cardsSection">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="list" class="item-content animate__animated animate__fadeIn  <?php echo e($listactive); ?>"
                    data-toggle-extra="tab-content">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between shadow-bottom">
                            <div class="h6"> <?php echo e(__('Maintenance List')); ?></div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <?php if(count($maintenances) == 0): ?>
                                            <div class="text-center p-5 m-5">
                                                <b> <?php echo e(__('No Maintenance')); ?> </b>
                                            </div>
                                        <?php else: ?>
                                            <div class="row">
                                                <div class="col-8">

                                                </div>
                                                <div class="col-md-4">
                                                    <input id="myInput" onkeyup="myFunction(1,[2,3,4,5,6]);"
                                                        type="text" placeholder="<?php echo e(__('Search')); ?>"
                                                        class="form-control">
                                                </div>
                                            </div>
                                            <br>
                                            <div class="card-body p-2">
                                                <table id="myTable" class="table rounded">
                                                    <thead>
                                                        <th>#</th>
                                                        <th><?php echo e(__('Date')); ?></th>
                                                        <th><?php echo e(__('Number')); ?></th>
                                                        <?php if((auth()->check() && auth()->user()->level != 3) || auth()->guard('client')->check()): ?>
                                                            <th><?php echo e(__('Facility')); ?></th>
                                                        <?php endif; ?>

                                                        <th><?php echo e(__('From Date')); ?></th>
                                                        <th><?php echo e(__('To Date')); ?></th>
                                                        <th><?php echo e(__('Days')); ?></th>
                                                        <th><?php echo e(__('Maintenance Agenda')); ?></th>
                                                        <th><?php echo e(__('Maintenance Team')); ?></th>

                                                        <th><?php echo e(__('Status')); ?></th>
                                                        
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $maintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $maintenance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>

                                                                <td><?php echo e($i + 1); ?></td>
                                                                <td><?php echo e($maintenance->created_at); ?></td>
                                                                <td><?php echo e($maintenance->number); ?></td>
                                                                <?php if((auth()->check() && auth()->user()->level != 3) || auth()->guard('client')->check()): ?>
                                                                    <td><?php echo e($maintenance->facility->title); ?></td>
                                                                <?php endif; ?>
                                                                <td><?php echo e($maintenance->startDate); ?></td>
                                                                <td><?php echo e($maintenance->endDate); ?> </td>
                                                                <td><?php echo e($maintenance->days); ?> </td>
                                                                <td><?php echo e($maintenance->description); ?> </td>
                                                                <td><?php echo e($maintenance->team); ?> </td>



                                                                <td> <?php switch($maintenance->status):
                                                                        case ('1'): ?>
                                                                            <span
                                                                                class="badge badge-success"><?php echo e(__('Approved')); ?></span>
                                                                        <?php break; ?>

                                                                        <?php case ('2'): ?>
                                                                            <span
                                                                                class="badge badge-warning"><?php echo e(__('Pending')); ?></span>
                                                                        <?php break; ?>

                                                                        <?php case ('3'): ?>
                                                                            <span
                                                                                class="badge badge-warning"><?php echo e(__('Pending')); ?></span>
                                                                        <?php break; ?>

                                                                        <?php case ('4'): ?>
                                                                            <span
                                                                                class="badge badge-danger"><?php echo e(__('Rejected')); ?></span>
                                                                        <?php break; ?>

                                                                        <?php case ('5'): ?>
                                                                            <span
                                                                                class="badge badge-info"><?php echo e(__('Canceled')); ?></span>
                                                                        <?php break; ?>

                                                                        <?php default: ?>
                                                                            <span
                                                                                class="badge badge-info"><?php echo e($maintenance->status); ?></span>
                                                                    <?php endswitch; ?>
                                                                </td>
                                                                


                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </tbody>
                                                </table>


                                            </div>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views\pages\maintenance\index.blade.php ENDPATH**/ ?>