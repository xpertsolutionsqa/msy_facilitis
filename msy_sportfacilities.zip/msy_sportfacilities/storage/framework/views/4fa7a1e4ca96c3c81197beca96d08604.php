
<style>
    .content-page {
        margin-right: 0px !important;
        margin-left: 0px !important;
        padding: 0px 10px 10px 0px !important;
    }
</style>

<?php $__env->startSection('content'); ?>
    <?php
        $facilities = \App\Models\Facility::where('status', '1')->get();
    ?>
    <div class="wrapper">


        <div class="content-page w-100">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex flex-wrap align-items-center justify-content-between breadcrumb-content">
                                    <h5><?php echo e(__('Facilities')); ?></h5>
                                    <div class="d-flex align-items-center">
                                        <div class="list-grid-toggle d-flex align-items-center mr-3">
                                            <div data-toggle-extra="tab" data-target-extra="#grid" class="active">
                                                <div class="grid-icon ">
                                                    <svg width="24" height="24" xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                        <rect x="3" y="3" width="7" height="7"></rect>
                                                        <rect x="14" y="3" width="7" height="7"></rect>
                                                        <rect x="14" y="14" width="7" height="7"></rect>
                                                        <rect x="3" y="14" width="7" height="7"></rect>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div data-toggle-extra="tab" data-target-extra="#list">
                                                <div class="grid-icon">
                                                    <svg width="24" height="24" xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                        <line x1="21" y1="10" x2="3" y2="10">
                                                        </line>
                                                        <line x1="21" y1="6" x2="3" y2="6">
                                                        </line>
                                                        <line x1="21" y1="14" x2="3" y2="14">
                                                        </line>
                                                        <line x1="21" y1="18" x2="3" y2="18">
                                                        </line>
                                                    </svg>

                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="grid" class="item-content animate__animated animate__fadeIn active"
                    data-toggle-extra="tab-content">

                    <div class="card">
                        <div class="card-body w-100 h-100">
                            <?php if(count($facilities) == 0): ?>
                                <div class="text-center p-5">
                                    <h5><b><?php echo e(__('Sorry No Facility Availabel To book')); ?></b></h5>
                                </div>
                            <?php else: ?>
                                <div class="row">
                                    <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $urls = rtrim($facility->images, ',');
                                            $images = explode(',', $urls);
                                        ?>
                                        <div class="card p-1 col-lg-3 col-md-6">
                                            <div class="card-transparent card-block card-stretch card-height">
                                                <div class="card-body text-center p-0 ">
                                                    <a
                                                        href="<?php echo e(route('facility.details', ['FaNumber' => $facility->number])); ?>">


                                                        <div class="item">



                                                            <div class="owl-carousel">
                                                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <img src="<?php echo e($image); ?>" alt=""
                                                                        srcset="">
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>

                                                            <div class="odr-content rounded">
                                                                <h4 class="mb-2">
                                                                    <?php echo e($facility->getTranslation('title', app()->getLocale())); ?>

                                                                </h4>
                                                                <p class="mb-3"> <?php echo e($facility->fulladdress); ?> </p>
                                                                <ul class="list-unstyled mb-3">
                                                                    <a target="_blank" href="<?php echo e($facility->location); ?>"
                                                                        class="bg-secondary-light rounded-circle iq-card-icon-small mr-4">
                                                                        <i class="ri-map-line m-0"></i>
                                                                    </a>
                                                                    <li
                                                                        class="bg-primary-light rounded-circle iq-card-icon-small mr-4">
                                                                        <i class="ri-chat-3-line m-0"></i>
                                                                    </li>
                                                                    <li
                                                                        class="bg-success-light rounded-circle iq-card-icon-small">
                                                                        <i class="ri-phone-line m-0"></i>
                                                                    </li>
                                                                </ul>
                                                                <div class="pt-3 border-top">
                                                                    <a href="#"
                                                                        class="btn btn-block btn-primary"><?php echo e(__('book')); ?></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>



                </div>
                <div id="list" class="item-content animate__animated animate__fadeIn  "
                    data-toggle-extra="tab-content">list</div>
            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views\home.blade.php ENDPATH**/ ?>