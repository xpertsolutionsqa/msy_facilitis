

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="iq-top-navbar-<?php echo e(app()->getLocale()); ?>">
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <h3><?php echo e(__('Admins')); ?></h3>
                                    <button class="btn p-1 m-0 btn-outline-primary" data-toggle-extra="tab"
                                        data-target="#create_admin_model" data-toggle="modal" type="button">
                                        <?php echo e(__('Add New Admin')); ?>

                                    </button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <?php if(count($admins) == 0): ?>
                                <div class="text-center p-5 m-5">
                                    <b> <?php echo e(__('No Admins')); ?> </b>
                                </div>
                            <?php else: ?>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-8">

                                        </div>
                                        <div class="col-md-4">
                                            <input id="myInput" onkeyup="myFunction(2,[1,2,3]);" type="text"
                                                placeholder="<?php echo e(__('Search')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <br>

                                    <table id="myTable" class="table table-border ">
                                        <thead>
                                            <tr>
                                                <th rowspan="2"> </th>

                                                <th style="vertical-align: middle;border-left:1px solid #E0E2DB"
                                                    rowspan="2"><?php echo e(__('Name')); ?></th>
                                                <th style="vertical-align: middle;border-left:1px solid #E0E2DB"
                                                    rowspan="2"><?php echo e(__('User Name')); ?></th>
                                                <th style="vertical-align: middle;border-left:1px solid #E0E2DB"
                                                    rowspan="2"><?php echo e(__('Email')); ?></th>
                                                <th style="vertical-align: middle;border-left:1px solid #E0E2DB"
                                                    rowspan="2"><?php echo e(__('Phone')); ?></th>
                                                <th style="vertical-align: middle;border-left:1px solid #E0E2DB"
                                                    rowspan="2"><?php echo e(__('Level')); ?></th>
                                                <th class="text-center" colspan="0"><?php echo e(__('Permissions')); ?></th>

                                            </tr>
                                            <tr>

                                                <th class="text-center"><?php echo e(__('Add Facility')); ?></th>

                                            </tr>

                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td> <?php echo e($i + 1); ?> </td>

                                                    <td><?php echo e($admin->displayname); ?></td>
                                                    <td><?php echo e($admin->username); ?></td>
                                                    <td><?php echo e($admin->email); ?></td>
                                                    <td><?php echo e($admin->phone); ?></td>
                                                    <td><?php echo e($admin->userType); ?></td>
                                                    <td class="text-center"> <input type="checkbox"
                                                            <?php echo e($admin->add_facility == '1' ? 'checked' : ''); ?>

                                                            <?php echo e($admin->email == $user->email ? 'disabled' : ''); ?>

                                                            class="form-control smallcheck changePer"
                                                            data_admin="<?php echo e($admin->id); ?>" data_name="add_facility">
                                                    </td>




                                                    <td>
                                                        <?php if($user->email != $admin->email): ?>
                                                            <form class="d-inline"
                                                                action="<?php echo e($admin->status == '1' ? route('user.disable') : route('user.enable')); ?>"
                                                                method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="adId"
                                                                    value="<?php echo e($admin->id); ?>">
                                                                <input type="hidden" name="adNumber"
                                                                    value="<?php echo e($admin->number); ?>">
                                                                <button type="submit"
                                                                    class="btn <?php echo e($admin->status == '1' ? 'btn-outline-warning' : 'btn-outline-primary'); ?>">
                                                                    <?php echo e($admin->status == '1' ? __('Disable') : __('Enable')); ?>

                                                                    <?php if($admin->status == '1'): ?>
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            viewBox="0 0 24 24" width="24"
                                                                            height="24" fill="currentColor">
                                                                            <path
                                                                                d="M12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20ZM12 10.5858L14.8284 7.75736L16.2426 9.17157L13.4142 12L16.2426 14.8284L14.8284 16.2426L12 13.4142L9.17157 16.2426L7.75736 14.8284L10.5858 12L7.75736 9.17157L9.17157 7.75736L12 10.5858Z">
                                                                            </path>
                                                                        </svg>
                                                                    <?php else: ?>
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            viewBox="0 0 24 24" width="24"
                                                                            height="24" fill="currentColor">
                                                                            <path
                                                                                d="M12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20ZM11.0026 16L6.75999 11.7574L8.17421 10.3431L11.0026 13.1716L16.6595 7.51472L18.0737 8.92893L11.0026 16Z">
                                                                            </path>
                                                                        </svg>
                                                                    <?php endif; ?>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>

                                                        <button type="button" userid="<?php echo e($admin->id); ?>"
                                                            usernumber="<?php echo e($admin->usernumber); ?>"
                                                            class="btn btn-outline-primary EditUser"> <?php echo e(__('Edit')); ?>

                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                                width="24" height="24" fill="currentColor">
                                                                <path
                                                                    d="M15.7279 9.57627L14.3137 8.16206L5 17.4758V18.89H6.41421L15.7279 9.57627ZM17.1421 8.16206L18.5563 6.74785L17.1421 5.33363L15.7279 6.74785L17.1421 8.16206ZM7.24264 20.89H3V16.6473L16.435 3.21231C16.8256 2.82179 17.4587 2.82179 17.8492 3.21231L20.6777 6.04074C21.0682 6.43126 21.0682 7.06443 20.6777 7.45495L7.24264 20.89Z">
                                                                </path>
                                                            </svg></button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="editUserModel"></div>
    <div id="deleteUserModel"></div>

    <div class="modal fade bd-example-modal-lg" role="dialog" aria-modal="true" id="create_admin_model">
        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header d-block text-center pb-3 border-bttom">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title">إضافة مستخدم جديد</h3>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('user.create')); ?>" id="createAdminForm" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="" class="required-label"><?php echo e(__('Name')); ?></label>
                                <input type="text" class="form-control required" name="displayname">
                            </div>
                            <div class="col-md-6">
                                <label for="" class="required-label"><?php echo e(__('User Name')); ?></label>
                                <input type="text" class="form-control required" name="username">
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-md-6">
                                <label for="" class="required-label"><?php echo e(__('Email')); ?></label>
                                <input type="email" class="form-control required" name="email">
                            </div>
                            <div class="col-md-6">
                                <label for="" class="required-label"><?php echo e(__('Phone')); ?></label>
                                <input type="text" class="form-control required" name="phone">
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-md-6">
                                <label for="" class="required-label"><?php echo e(__('Level')); ?></label>
                                <select name="level" class="form-control required " id="userLevel">
                                    <?php $__currentLoopData = \App\Models\UserLevel::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($level->id); ?>"> <?php echo e($level->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6" id="clubselect" style="display: none">
                                <label for="" class="required-label"><?php echo e(__('Club')); ?></label>
                                <select name="club" id="userClub" class="form-control required">
                                    <?php $__currentLoopData = \App\Models\Club::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($club->id); ?>"> <?php echo e($club->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class=" align-items-center">
                                    <div class="card p-2"> <label for="permissions">الصلاحيات </label>
                                        <div class="d-flex p-2">
                                            <input type="checkbox" class="form-control smallcheck" name="add_facility">
                                            <span class="space"> إضافة منشأة جديدة</span>

                                        </div>
                                        <div class="error-msg" id="per-error-msg"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <button type="button" class="btn btn-outline-danger btn-block" data-dismiss="modal"
                                    aria-label="Close"> إلغاء </button>
                            </div>
                            <div class="col-6">

                                <button class="btn-block btn btn-outline-primary" type="submit">إضافة</button>
                            </div>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn-script.com/ajax/libs/jquery/3.7.1/jquery.js"></script>
    <script>
        $(".changePer").change(function() {

            var newvalue = $(this).prop("checked");
            var userid = $(this).attr('data_admin');
            var field = $(this).attr('data_name');
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                type: 'POST',
                url: ' <?php echo e(route('changePer')); ?>',
                headers: {
                    'X-CSRF-TOKEN': csrfToken
                },
                data: {
                    field: field,
                    userid: userid,
                    newvalue: newvalue
                },
                success: function(data) {
                    Swal.fire({
                        toast: true,
                        position: "top-start",
                        icon: "success",
                        title: "<?php echo e(__('Updated')); ?>",
                        showConfirmButton: false,
                        timer: 1500
                    });
                },
                error: function(error) {
                    Swal.fire({
                        toast: true,
                        position: "top-start",
                        icon: "error",
                        title: "<?php echo e(__('Something Wrong')); ?>",
                        showConfirmButton: false,
                        timer: 1500
                    });
                }
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views\pages\admins.blade.php ENDPATH**/ ?>