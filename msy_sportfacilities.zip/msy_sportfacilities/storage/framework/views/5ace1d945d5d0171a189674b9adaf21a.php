
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="iq-top-navbar-<?php echo e(app()->getLocale()); ?>">
           <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">

                                <h3><?php echo e(__('Languages')); ?></h3>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="row">
                                <div class="col-xl-12">
                                    <form action="<?php echo e(route('settings.languages.save')); ?>" id="LangForm" method="post">
                                        <?php echo csrf_field(); ?>

                                        <div class="row">
                                            <div class="col-8">

                                            </div>
                                            <div class="col-md-4">
                                                <input id="myInput" onkeyup="myFunction(1,[0]);" type="text"
                                                    placeholder="<?php echo e(__('Search')); ?>" class="form-control">
                                            </div>
                                        </div>
                                        <br>

                                        <table id="myTable" class="table table-border ">
                                            <thead>
                                                <tr>
                                                    <th>المفتاح | KEY</th>
                                                    <th width="25%">بالعربي</th>
                                                    <th width="25%">In English</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $arlabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td> <label class="form-label"
                                                                for="example3cols1Input"><?php echo e($label); ?>

                                                            </label></td>
                                                        <td><input class="form-control" type="text"
                                                                value="<?php echo e($value); ?>"
                                                                name="arlabel[<?php echo e($label); ?>]" id=""></td>
                                                        <td><input class="form-control" type="text"
                                                                value="<?php echo e(isset($enlabels->$label) ? $enlabels->$label : ''); ?>"
                                                                name="enlabel[<?php echo e($label); ?>]" id=""></td>

                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </form>
                                </div>



                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views/pages/lang/manage.blade.php ENDPATH**/ ?>