<?php if(Auth::guard('client')->check()): ?>
    <?php
        $user = Auth::guard('client')->user();
    ?>
    <div class="iq-navbar-custom">
        <nav class="d-flex navbar navbar-expand-lg navbar-light p-0 justify-content-between p-3">
            <div class="  iq-navbar-logo d-flex align-items-center justify-content-between">
                <i class="ri-menu-line wrapper-menu"></i>
                <a href="<?php echo e(route('facilities')); ?>" class="header-logo">
                    <h4 class="logo-title text-uppercase"> </h4>

                </a>
            </div>

            <a href="<?php echo e(route('dashboard')); ?>"> <img
                    class="<?php echo e(app()->getLocale() == 'ar' ? 'border-left' : 'border-right '); ?> pr-3  pl-3"
                    style="width: 250px" src="<?php echo e(asset('assets/images/logo/msy_new_logo.png')); ?>" alt="logo"></a>
            <div>
                <p>
                    <?php

                        $date = Carbon\Carbon::now()->addHour(3);
                        $locale = app()->getLocale();
                        $formattedDateEn = $date->locale('en')->translatedFormat('l j F Y');
                        $timeInEnglish = $date->format('g:i A');
                        $formattedDateAr = $date->locale('ar')->translatedFormat('l j F Y');
                        $timeInArabic = $date->format('h:i') . ' ' . ($date->format('A') === 'AM' ? 'صباحا' : 'مساءا');
                        $todaysDate = $locale === 'ar' ? $formattedDateAr : $formattedDateEn;
                        $todaysTime = $locale === 'ar' ? $timeInArabic : $timeInEnglish;
                    ?>

                    <?php echo e($todaysDate); ?> - <?php echo e($todaysTime); ?> &nbsp;&nbsp;&nbsp;

                    <button class="btn" type="button" id="popoverButton">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32" height="32"
                            fill="currentColor">
                            <path
                                d="M9.98392 5.05991C11.1323 3.22236 13.1734 2 15.5 2C19.0899 2 22 4.91015 22 8.5C22 9.58031 21.7365 10.5991 21.2701 11.4955C22.3351 12.4985 23 13.9216 23 15.5C23 18.5376 20.5376 21 17.5 21H9C4.58172 21 1 17.4183 1 13C1 8.58172 4.58172 5 9 5C9.33312 5 9.66149 5.02036 9.98392 5.05991ZM12.0554 5.60419C14.0675 6.43637 15.6662 8.06578 16.4576 10.0986C16.7951 10.0339 17.1436 10 17.5 10C18.2351 10 18.9366 10.1442 19.5776 10.4059C19.8486 9.82719 20 9.18128 20 8.5C20 6.01472 17.9853 4 15.5 4C14.1177 4 12.8809 4.6233 12.0554 5.60419ZM17.5 19C19.433 19 21 17.433 21 15.5C21 13.567 19.433 12 17.5 12C16.5205 12 15.6351 12.4023 14.9998 13.0507C14.9999 13.0338 15 13.0169 15 13C15 9.68629 12.3137 7 9 7C5.68629 7 3 9.68629 3 13C3 16.3137 5.68629 19 9 19H17.5Z">
                            </path>
                        </svg>
                    </button>


                </p>

            </div>


            <div class="d-flex align-items-center">
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-label="Toggle navigation">
                    <i class="ri-menu-3-line"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent"
                    style="font-family: 'Line Awesome Free'">
                    <ul class="navbar-nav ml-auto navbar-list align-items-center">

                        <li class="nav-item nav-icon dropdown caption-content">
                            <a href="#" class="search-toggle dropdown-toggle  d-flex align-items-center"
                                id="dropdownMenuButton4" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">

                                <div class="caption mh-3">
                                    <h6 class="mb-0 line-height"><?php echo e($user->displayname); ?> <svg
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24"
                                            height="24" fill="currentColor">
                                            <path
                                                d="M11.9999 13.1714L16.9497 8.22168L18.3639 9.63589L11.9999 15.9999L5.63599 9.63589L7.0502 8.22168L11.9999 13.1714Z">
                                            </path>
                                        </svg>
                                    </h6>
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-left border-none"
                                aria-labelledby="dropdownMenuButton">
                                <li class="dropdown-item  d-flex svg-icon border-top">

                                    <?php
                                        $string = request()->route()->getName();
                                        $modifiedString = str_replace('.', '_', $string);
                                    ?>

                                    <div data-target="#edit_password_model" data-toggle="modal" class="ph-3 active">
                                        <?php echo e(__('Edit your password')); ?> <i class="ri-key-2-line"></i>
                                    </div>

                                </li>
                                <li class="dropdown-item  d-flex svg-icon border-top">
                                    <?php if(app()->getLocale() == 'ar'): ?>
                                        <a class="btn  " href="<?php echo e(route('lang.switch', 'en')); ?>"><i
                                                class="ri-translate"></i> Change
                                            To English</a>
                                    <?php else: ?>
                                        <div class="ph-3">
                                            <a class="text-center btn" href="<?php echo e(route('lang.switch', 'ar')); ?>">تغيير
                                                للغة للعربيه <i class="ri-translate"></i></a>
                                        </div>
                                    <?php endif; ?>
                                </li>
                                <li class="dropdown-item  d-flex svg-icon border-top">

                                    <form method="POST" action="<?php echo e(route('client.logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button class=" btn " type="submit"><?php echo e(__('Logout')); ?></button>
                                    </form>

                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24"
                                        height="24" fill="currentColor">
                                        <path
                                            d="M4 18H6V20H18V4H6V6H4V3C4 2.44772 4.44772 2 5 2H19C19.5523 2 20 2.44772 20 3V21C20 21.5523 19.5523 22 19 22H5C4.44772 22 4 21.5523 4 21V18ZM6 11H13V13H6V16L1 12L6 8V11Z">
                                        </path>
                                    </svg>

                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
<?php elseif(Auth::check()): ?>
    <?php
        $user = Auth::user();
    ?>
    <div class="iq-navbar-custom">
        <nav class="d-flex navbar navbar-expand-lg navbar-light p-0 justify-content-between p-3">
            <div class="  iq-navbar-logo d-flex align-items-center justify-content-between ">

                <i class="ri-menu-line wrapper-menu"></i>
                <a href="<?php echo e(route('facilities')); ?>" class="header-logo">
                    <h4 class="logo-title text-uppercase"> </h4>

                </a>
            </div>
            <a href="<?php echo e(route('dashboard')); ?>"> <img
                    class="<?php echo e(app()->getLocale() == 'ar' ? 'border-left' : 'border-right '); ?> pr-3  pl-3"
                    style="width: 250px" src="<?php echo e(asset('assets/images/logo/msy_new_logo.png')); ?>" alt="logo"></a>
            <div>
                <p>
                    <?php

                        $date = Carbon\Carbon::now()->addHour(3);
                        $locale = app()->getLocale();
                        $formattedDateEn = $date->locale('en')->translatedFormat('l j F Y');
                        $timeInEnglish = $date->format('g:i A');
                        $formattedDateAr = $date->locale('ar')->translatedFormat('l j F Y');
                        $timeInArabic = $date->format('h:i') . ' ' . ($date->format('A') === 'AM' ? 'صباحا' : 'مساءا');
                        $todaysDate = $locale === 'ar' ? $formattedDateAr : $formattedDateEn;
                        $todaysTime = $locale === 'ar' ? $timeInArabic : $timeInEnglish;
                    ?>

                    <?php echo e($todaysDate); ?> - <?php echo e($todaysTime); ?> &nbsp;&nbsp;&nbsp;

                    <button class="btn" type="button" id="popoverButton">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32" height="32"
                            fill="currentColor">
                            <path
                                d="M9.98392 5.05991C11.1323 3.22236 13.1734 2 15.5 2C19.0899 2 22 4.91015 22 8.5C22 9.58031 21.7365 10.5991 21.2701 11.4955C22.3351 12.4985 23 13.9216 23 15.5C23 18.5376 20.5376 21 17.5 21H9C4.58172 21 1 17.4183 1 13C1 8.58172 4.58172 5 9 5C9.33312 5 9.66149 5.02036 9.98392 5.05991ZM12.0554 5.60419C14.0675 6.43637 15.6662 8.06578 16.4576 10.0986C16.7951 10.0339 17.1436 10 17.5 10C18.2351 10 18.9366 10.1442 19.5776 10.4059C19.8486 9.82719 20 9.18128 20 8.5C20 6.01472 17.9853 4 15.5 4C14.1177 4 12.8809 4.6233 12.0554 5.60419ZM17.5 19C19.433 19 21 17.433 21 15.5C21 13.567 19.433 12 17.5 12C16.5205 12 15.6351 12.4023 14.9998 13.0507C14.9999 13.0338 15 13.0169 15 13C15 9.68629 12.3137 7 9 7C5.68629 7 3 9.68629 3 13C3 16.3137 5.68629 19 9 19H17.5Z">
                            </path>
                        </svg>
                    </button>


                </p>

            </div>
            <?php if(Route::current()->getName() == 'settings.languages'): ?>
                <button class="btn btn-success langBtn"><?php echo e(__('Update')); ?> </button>
            <?php endif; ?>

            <div class="d-flex align-items-center">
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-label="Toggle navigation">
                    <i class="ri-menu-3-line"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent"
                    style="font-family: 'Line Awesome Free'">
                    <ul class="navbar-nav ml-auto navbar-list align-items-center">

                        <li class="nav-item nav-icon dropdown caption-content">
                            <a href="#" class="search-toggle dropdown-toggle  d-flex align-items-center"
                                id="dropdownMenuButton4" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">

                                <div class="caption mh-3">
                                    <h6 class="mb-0 line-height"><?php echo e($user->displayname); ?> <svg
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24"
                                            height="24" fill="currentColor">
                                            <path
                                                d="M11.9999 13.1714L16.9497 8.22168L18.3639 9.63589L11.9999 15.9999L5.63599 9.63589L7.0502 8.22168L11.9999 13.1714Z">
                                            </path>
                                        </svg>
                                    </h6>
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-right border" aria-labelledby="dropdownMenuButton">


                                <li class="dropdown-item  d-flex svg-icon  ">
                                    <?php if(app()->getLocale() == 'ar'): ?>
                                        <a class="btn  " href="<?php echo e(route('lang.switch', 'en')); ?>"><i
                                                class="ri-translate"></i> Change
                                            To English</a>
                                    <?php else: ?>
                                        <div class="ph-3">
                                            <a class="text-center btn" href="<?php echo e(route('lang.switch', 'ar')); ?>">تغيير
                                                للغة للعربيه <i class="ri-translate"></i></a>
                                        </div>
                                    <?php endif; ?>
                                </li>
                                <li class="dropdown-item  d-flex svg-icon border-top">

                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button class=" btn " type="submit"><?php echo e(__('Logout')); ?></button>
                                    </form>

                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24"
                                        height="24" fill="currentColor">
                                        <path
                                            d="M4 18H6V20H18V4H6V6H4V3C4 2.44772 4.44772 2 5 2H19C19.5523 2 20 2.44772 20 3V21C20 21.5523 19.5523 22 19 22H5C4.44772 22 4 21.5523 4 21V18ZM6 11H13V13H6V16L1 12L6 8V11Z">
                                        </path>
                                    </svg>

                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
<?php endif; ?>
<?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views\layouts\header.blade.php ENDPATH**/ ?>