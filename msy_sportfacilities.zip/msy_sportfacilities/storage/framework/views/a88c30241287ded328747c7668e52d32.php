<div class="border  ">
    <div class=" p-2 blur-shadow ">

        <div class="d-flex justify-content-between align-items-center">
            <h6 class="text-center"> <b><?php echo e($booking->event_name); ?></b></h6>
            <div class="text-center">

                <p style="font-size: 13px">
                    <samll> <?php echo e(__('Created At')); ?> : <?php echo e($booking->created_at); ?></small>
                </p>
                <?php echo $booking->htmlstatus; ?>

            </div>
        </div>
    </div>


    <div class="card-body">

        <p class="border-info text-info border p-1 ">
            <?php echo e(__('From Date') . ' ' . $booking->start_date . ' ' . $booking->start_time . '   ' . __('To Date') . ' ' . $booking->end_date . ' ' . $booking->end_time); ?>



        <div class="d-flex justify-content-between ">
            <p class="border border-primary text-primary   p-2  "><?php echo e(__('Requierd Days No') . ' : ' . $booking->days); ?>

            </p>
            <p class="border border-danger text-danger   p-2  ">
                <?php echo e(__('Expected Participants No') . ' : ' . $booking->particpations); ?>

            </p>
        </div>

        <div class="blur-shadow   p-2 <?php echo e(app()->getLocale() == 'ar' ? 'text-right' : 'text-left'); ?> ">
            <p><b><?php echo e(__('Requierd Sub Facilities')); ?></b></p>
            <ul>
                <?php $__currentLoopData = $booking->subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class=" ph-4 "><?php echo e($item->title . ' : (' . $item->type . ')'); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>



        </div>

        



        
        
        <div class="p-1"></div>
        <div class="blur-shadow <?php echo e(app()->getLocale() == 'ar' ? 'text-right' : 'text-left'); ?> p-2">
            <small><?php echo e($booking->notes); ?></small>
        </div>


    </div>
    <div class="card-footer">
        <a href="<?php echo e(route('booking.details', $booking->number)); ?>"
            class="btn btn-block btn-outline-primary"><?php echo e(__('Details')); ?>


            <?php if(app()->getlocale() == 'ar'): ?>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"
                    fill="currentColor">
                    <path
                        d="M7.82843 10.9999H20V12.9999H7.82843L13.1924 18.3638L11.7782 19.778L4 11.9999L11.7782 4.22168L13.1924 5.63589L7.82843 10.9999Z">
                    </path>
                </svg>
            <?php else: ?>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"
                    fill="currentColor">
                    <path
                        d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z">
                    </path>
                </svg>
            <?php endif; ?>

        </a>

    </div>
</div>
<?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views\pages\bookings\bookingcard.blade.php ENDPATH**/ ?>