

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="iq-top-navbar-<?php echo e(app()->getLocale()); ?>">
           <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <a href="<?php echo e(route('facility.details', ['FaNumber' => $facility->number])); ?>"
                                        class="btn btn-outline-info"><back-icon></back-icon><?php echo e(__('Go Back')); ?> </a>
                                    <h3><?php echo e(__('Edit Facility')); ?></h3>
                                    <div class="p-3"></div>
                                </div>

                            </div>
                        </div>
                        <?php if(isset($facility->images) && count($facility->images) > 0): ?>
                            <div class="row">
                                <?php $__currentLoopData = $facility->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 card p-2" id="imageCard<?php echo e($i); ?>">
                                        <img src="<?php echo e(config('app.url')); ?>/<?php echo e($image->url); ?>" alt="image" srcset="">
                                        <?php if(count($facility->images) > 1): ?>
                                            <br>
                                            <form action="<?php echo e(route('facility.removeimage')); ?>" method="post">

                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($facility->id); ?>">
                                                <input type="hidden" name="number" value="<?php echo e($facility->number); ?>">
                                                <input type="hidden" name="path" value="<?php echo e($image->url); ?>">
                                                <button type="submit" class="btn btn-block btn-outline-danger  ">
                                                    <?php echo e(__('Delete')); ?></button>
                                            </form>
                                        <?php endif; ?>


                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($facility->images) < 4): ?>
                                    <div class=" card col-md-3 h-100 p-3">
                                        <form action="<?php echo e(route('facility.addimage')); ?>" method="post"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($facility->number); ?>" name="number">
                                            <input type="hidden" value="<?php echo e($facility->id); ?>" name="id">

                                            <input class="form-control required " max="2" type="file"
                                                accept=".png,.jpg,.jpeg" name="images[]" multiple>
                                            <br><br>
                                            <button type="submit"
                                                class="btn btn-block p-2 btn-outline-success"><?php echo e(__('Add Images')); ?></button>

                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-center"><?php echo e(__('No Images for this Facility')); ?></p> <br>
                            <form action="<?php echo e(route('facility.addimage')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($facility->number); ?>" name="number">
                                <input type="hidden" value="<?php echo e($facility->id); ?>" name="id">

                                <input class="form-control required " type="file" accept=".png,.jpg,.jpeg"
                                    name="images[]" multiple>
                                <br><br>
                                <button type="submit"
                                    class="btn btn-block p-2 btn-outline-success"><?php echo e(__('Add Images')); ?></button>

                            </form>
                        <?php endif; ?>
                        <form class="card p-2 " action="<?php echo e(route('facility.update')); ?>" method="post"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="number" value="<?php echo e($facility->number); ?>">
                            <input type="hidden" name="id" value="<?php echo e($facility->id); ?>">
                            <div class="card p-2">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="ar_name" class="required-label"><?php echo e(__('Ar Name')); ?></label>
                                        <input type="text" class="form-control required" name="ar_name"
                                            value="<?php echo e($facility->getTranslation('title', 'ar')); ?>"
                                            placeholder="<?php echo e(__('Ar Name')); ?>" />
                                    </div>
                                    <div class="col-md-6" class="required-label">
                                        <label for="en_name" class="required-label"><?php echo e(__('En Name')); ?></label>
                                        <input type="text" class="form-control required" name="en_name"
                                            value="<?php echo e($facility->getTranslation('title', 'en')); ?>"
                                            placeholder="<?php echo e(__('En Name')); ?>" />
                                    </div>

                                </div>
                                <div class="p-2"></div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="gender1" class=" required-label"> <?php echo e(__('Facility Type')); ?>

                                        </label><br>
                                        <div class="d-flex p-2">
                                            <?php $__currentLoopData = \App\Models\FacilityTypes::where('status', '1')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <input type="radio" <?php echo e($type->id == $facility->type ? 'checked' : ''); ?>

                                                    class="form-control radio smallradio required" name="type"
                                                    value="<?php echo e($type->id); ?>"> <span
                                                    class="space"><?php echo e($type->getTranslation('name', app()->getLocale())); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="space" class="required-label"><?php echo e(__('Space')); ?></label>
                                        <input type="text" class="form-control required" name="space"
                                            value="<?php echo e($facility->space); ?>" placeholder="<?php echo e(__('Space')); ?>" />
                                    </div>
                                    <div class="col-md-4">
                                        <label for="capacity" class="required-label"><?php echo e(__('Capacity')); ?></label>
                                        <input type="text" class="form-control required" name="capacity"
                                            value="<?php echo e($facility->capacity); ?>" placeholder="<?php echo e(__('Capacity')); ?>" />
                                    </div>
                                </div>



                                <div class="p-2"></div>

                            </div>
                            <br>
                            <div class="card p-2">
                                <h6><?php echo e(__('Address')); ?></h6>
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="zone" class="required-label"><?php echo e(__('Zone')); ?></label>
                                        <input type="number" class="form-control required" name="zone"
                                            value="<?php echo e($facility->zone); ?>" placeholder="<?php echo e(__('Zone')); ?>" />
                                    </div>
                                    <div class="col-md-3">
                                        <label for="buliding" class="required-label"><?php echo e(__('Building No')); ?></label>
                                        <input type="text" class="form-control required" name="buliding"
                                            value="<?php echo e($facility->building); ?>" placeholder="<?php echo e(__('Building No')); ?>" />
                                    </div>
                                    <div class="col-md-3">
                                        <label for="street" class="required-label"><?php echo e(__('Street No')); ?></label>
                                        <input type="text" class="form-control required" name="street"
                                            value="<?php echo e($facility->street); ?>" placeholder="<?php echo e(__('Street No')); ?>" />
                                    </div>
                                    <div class="col-md-3">
                                        <label for="street" class="required-label"><?php echo e(__('Location')); ?></label>
                                        <input type="text" class="form-control required" name="location"
                                            value="<?php echo e($facility->location); ?>" placeholder="<?php echo e(__('Location')); ?>" />
                                    </div>

                                </div>
                            </div>
                            <input type="hidden" id="count" value="1" name="subconunt">


                            <button type="submit" class="btn btn-block btn-outline-success"> <?php echo e(__('Edit')); ?>

                            </button>
                        </form>

                        <div class="card">
                            <div class="card-body p-2">
                                <div class="d-flex p-2 justify-content-between">
                                    <h6><?php echo e(__('Sub Facilities')); ?></h6>
                                    <button type="button" data-toggle-extra="tab" data-target="#create_sub_fa_model"
                                        data-toggle="modal"
                                        class="btn btn-outline-primary "><?php echo e(__('Create New Sub Facility')); ?>

                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24"
                                            height="24" fill="currentColor">
                                            <path
                                                d="M11 11V7H13V11H17V13H13V17H11V13H7V11H11ZM12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20Z">
                                            </path>
                                        </svg></button>
                                </div>
                                <?php if(count($facility->subfacilities) > 0): ?>
                                    <div class="border p-2">

                                        <div class="row border-bottom">
                                            <div class="col-md-10">
                                                <div class="row">
                                                    <div class="col-md-2 text-center "><?php echo e(__('Ar Name')); ?></div>
                                                    <div class="col-md-2 text-center "><?php echo e(__('En Name')); ?></div>
                                                    <div class="col-md-2 text-center "><?php echo e(__('Type')); ?></div>
                                                    <div class="col-md-2 text-center "><?php echo e(__('Capacity')); ?></div>
                                                    <div class="col-md-2 text-center "><?php echo e(__('Description')); ?></div>
                                                    <div class="col-md-2 text-center "> </div>
                                                </div>
                                            </div>


                                        </div>

                                        <?php $__currentLoopData = $facility->subfacilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row <?php echo e($sub->status != '1' ? 'readTR m-1' : ''); ?>">
                                                <div class="col-md-10">
                                                    <form action="<?php echo e(route('sub.edit')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="number"
                                                            value="<?php echo e($facility->number); ?>">
                                                        <input type="hidden" name="sub"
                                                            value="<?php echo e($sub->id); ?>">
                                                        <input type="hidden" name="id"
                                                            value="<?php echo e($facility->id); ?>">
                                                        <div class="row p-1">
                                                            <div class="col-md-2">
                                                                <input type="text" class="form-control required"
                                                                    value="<?php echo e($sub->getTranslation('title', 'ar')); ?>"
                                                                    name="arname" placeholder="<?php echo e(__('Ar Name')); ?> *" />
                                                            </div>
                                                            <div class="col-md-2">
                                                                <input type="text" class="form-control required"
                                                                    value="<?php echo e($sub->getTranslation('title', 'en')); ?>"
                                                                    name="enname" placeholder="<?php echo e(__('En Name')); ?> *" />
                                                            </div>
                                                            <div class="col-md-2">
                                                                <input type="text" class="form-control required"
                                                                    value="<?php echo e($sub->type); ?>" name="type"
                                                                    placeholder="<?php echo e(__('Type')); ?> *" />
                                                            </div>
                                                            <div class="col-md-2">
                                                                <input type="text" class="form-control required"
                                                                    name="capacity" value="<?php echo e($sub->size); ?>"
                                                                    placeholder="<?php echo e(__('Capacity')); ?> *" />
                                                            </div>
                                                            <div class="col-md-2">
                                                                <textarea type="text" rows="1" class="form-control" name="description"
                                                                    placeholder="<?php echo e(__('Description')); ?>" /><?php echo $sub->description; ?></textarea>
                                                            </div>
                                                            <div class="col-md-1">
                                                                <button type="submit"
                                                                    class="btn btn-outline-danger"><?php echo e(__('Edit')); ?></button>
                                                            </div>
                                                        </div>

                                                    </form>

                                                </div>
                                                <div class="col-md-2">
                                                    <div class="d-flex align-items-center justify-content-center">


                                                        <form class="d-inline "
                                                            action="<?php echo e($sub->status == '1' ? route('subfacility.disable') : route('subfacility.enable')); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="sub"
                                                                value="<?php echo e($sub->id); ?>">
                                                            <input type="hidden" name="id"
                                                                value="<?php echo e($facility->id); ?>">
                                                            <button type="submit"
                                                                class="btn m-1 <?php echo e($sub->status == '1' ? 'btn-outline-warning' : 'btn-outline-primary'); ?>">
                                                                <?php echo e($sub->status == '1' ? __('Disable') : __('Enable')); ?>

                                                                <?php if($sub->status == '1'): ?>
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                        viewBox="0 0 24 24" width="24" height="24"
                                                                        fill="currentColor">
                                                                        <path
                                                                            d="M12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20ZM12 10.5858L14.8284 7.75736L16.2426 9.17157L13.4142 12L16.2426 14.8284L14.8284 16.2426L12 13.4142L9.17157 16.2426L7.75736 14.8284L10.5858 12L7.75736 9.17157L9.17157 7.75736L12 10.5858Z">
                                                                        </path>
                                                                    </svg>
                                                                <?php else: ?>
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                        viewBox="0 0 24 24" width="24" height="24"
                                                                        fill="currentColor">
                                                                        <path
                                                                            d="M12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22ZM12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20ZM11.0026 16L6.75999 11.7574L8.17421 10.3431L11.0026 13.1716L16.6595 7.51472L18.0737 8.92893L11.0026 16Z">
                                                                        </path>
                                                                    </svg>
                                                                <?php endif; ?>
                                                            </button>
                                                        </form>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="row">


                                                        <?php $__currentLoopData = $sub->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="card m-1 col-md-2">
                                                                <img class="rounded p-1"
                                                                    src="<?php echo e(config('app.url')); ?>/<?php echo e($img->url); ?>"
                                                                    alt="a" srcset="">
                                                                <form action="<?php echo e(route('subimage.remove')); ?>"
                                                                    method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="sub"
                                                                        value="<?php echo e($sub->id); ?>">
                                                                    <input type="hidden" name="id"
                                                                        value="<?php echo e($facility->id); ?>">
                                                                    <input type="hidden" name="url"
                                                                        value="<?php echo e($img->url); ?>">
                                                                    <button type="submit"
                                                                        class="btn btn-block btn-outline-danger"><?php echo e(__('Delete')); ?></button>
                                                                </form>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <div class=" card d-flex align-items-center justify-content-center col-md-2">

                                                            <form action="<?php echo e(route('subimage.add')); ?>" method="post"
                                                                enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="file" accept=".png,.jpeg,.jpg"
                                                                    name="images[]" multiple
                                                                    class="form-control required">
                                                                    <div class="p-2"></div>
                                                                <input type="hidden" name="sub"
                                                                    value="<?php echo e($sub->id); ?>">
                                                                <input type="hidden" name="id"
                                                                    value="<?php echo e($facility->id); ?>">
                                                                
                                                                <button type="submit"
                                                                    class="btn btn-block btn-outline-info"><?php echo e(__('Add')); ?></button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>



                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <div class="text-center">
                                        <p class="h6"><?php echo e(__('No Sub Facilities added')); ?></p><br>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>





    <div class="modal fade bd-example-modal-lg" role="dialog" aria-modal="true" id="create_sub_fa_model">
        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header d-block text-center pb-3 border-bttom">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h3 class="modal-title"><?php echo e(__('Create New Sub Facility')); ?> </h3>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('subfacility.create')); ?> " enctype="multipart/form-data" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="FaId" value="<?php echo e($facility->id); ?>">
                        <input type="hidden" name="FaNum" value="<?php echo e($facility->number); ?>">
                        <div class="form-groug row p-3">
                            <div class="col-md-6">
                                <label class="required-label" for=""><?php echo e(__('Ar Name')); ?></label>
                                <input type="text" name="arname" class="form-control required">
                            </div>
                            <div class="col-md-6">
                                <label class="required-label" for=""><?php echo e(__('En Name')); ?></label>
                                <input type="text" name="enname" class="form-control required">
                            </div>
                            <div class="col-md-4">
                                <label class="required-label" for=""><?php echo e(__('Type')); ?></label>
                                <input type="text" name="type" class="form-control required">
                            </div>
                            <div class="col-md-4">
                                <label class="required-label" for=""><?php echo e(__('Capacity')); ?></label>
                                <input type="text" name="capacity" class="form-control required">
                            </div>
                            <div class="col-md-4">
                                <label class="required-label" for=""><?php echo e(__('Images')); ?></label>
                                <input type="file" multiple accept=".png,.jpg,.jpeg" name="images[]" class="form-control required">
                            </div>


                        </div>
                        <div class="row p-1">
                            <div class="col-md-12">
                                <label for=""><?php echo e(__('Description')); ?></label>
                                <textarea name="description" class="form-control" rows="3"></textarea>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-6">
                                <button type="button" class="btn btn-outline-danger btn-block" data-dismiss="modal"
                                    aria-label="Close"> <?php echo e(__('Cancel')); ?> </button>
                            </div>
                            <div class="col-6">

                                <button class="btn-block btn btn-outline-primary"
                                    type="submit"><?php echo e(__('Add')); ?></button>
                            </div>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views/pages/facility/edit.blade.php ENDPATH**/ ?>