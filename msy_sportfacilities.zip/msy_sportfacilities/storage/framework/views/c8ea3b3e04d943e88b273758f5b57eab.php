

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="iq-top-navbar">
           <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="content-page">
            <div class="container-fluid">
                
                <div class="card p-5">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h6><?php echo e(__("Contact Us")); ?> </h6>
                            <button class="btn btn-outline-success" type="button" data-toggle="collapse"
                                data-target="#contact" aria-expanded="false" aria-controls="contact">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32" height="32"
                                    fill="currentColor">
                                    <path d="M12 16L6 10H18L12 16Z"></path>
                                </svg></button>
                        </div>

                        <div class="collapse multi-collapse" id="contact">


                            <form action="<?php echo e(route('UpdateContact')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                 
                                    <div class="col-md-2">  
                                        <label for="location"> <?php echo e(__("Facebook Url")); ?></label>
                                        <input class="form-control" type="text" name="facebook" value="<?php echo e($facebook); ?>"> 
                                    </div>
                                    <div class="col-md-2">  
                                        <label for="location"> <?php echo e(__("X Url")); ?></label>
                                        <input class="form-control" type="text" name="x" value="<?php echo e($x); ?>"> 
                                    </div>
                                    <div class="col-md-2">  
                                        <label for="location"> <?php echo e(__("SnapChat Url")); ?></label>
                                        <input class="form-control" type="text" name="snapchat" value="<?php echo e($snapchat); ?>"> 
                                    </div>
                                    <div class="col-md-2">  
                                        <label for="location"> <?php echo e(__("Instagram Url")); ?></label>
                                        <input class="form-control" type="text" name="instagram" value="<?php echo e($instagram); ?>"> 
                                    </div>
                                    <div class="col-md-2">  
                                        <label for="location"> <?php echo e(__("Website Url")); ?></label>
                                        <input class="form-control" type="text" name="web" value="<?php echo e($web); ?>"> 
                                    </div>
                                
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="location"> <?php echo e(__("Google map Location")); ?></label>
                                        <input class="form-control" type="text" name="location"
                                            value="<?php echo e($location); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="ar_address"> <?php echo e(__("Phone Number")); ?></label>
                                        <input class="form-control" type="text" name="phone"
                                            value="<?php echo e($phone); ?>">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="latitude"> Latitude</label>
                                        <input class="form-control" type="text" name="latitude"
                                            value="<?php echo e($latitude); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="longitude">Longitude</label>
                                        <input class="form-control" type="text" name="longitude"
                                            value="<?php echo e($longitude); ?>">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="en_address"> <?php echo e(__("En Address")); ?></label>
                                        <textarea class="form-control" type="text" name="en_address" value="<?php echo e($en_address); ?>"> <?php echo $en_address; ?>

                                    </textarea>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="ar_address"> <?php echo e(__("Ar Address")); ?></label>
                                        <textarea class="form-control" type="text" name="ar_address" value="<?php echo e($ar_address); ?>"> <?php echo $ar_address; ?>

                                    </textarea>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end p-2">
                                    <button type="submit" class="btn btn-success"><?php echo e(__("Update")); ?></button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                <div class="card p-5">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h6 for=""><?php echo e(__("About Us")); ?></h6>
                            <button id="updateAboutUsBtn" class="btn btn-outline-primary hidden"> <?php echo e(__("Save Changes")); ?></button>
                            <button class="btn btn-outline-success" type="button" data-toggle="collapse"
                                data-target="#about_us" aria-expanded="false" aria-controls="about_us">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32" height="32"
                                    fill="currentColor">
                                    <path d="M12 16L6 10H18L12 16Z"></path>
                                </svg></button>
                        </div>


                        <div class="collapse multi-collapse" id="about_us">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for=""><?php echo e(__("In English")); ?></label>
                                    <div class="card" id="english_aboutuseditor"><?php echo $english_aboutus; ?></div>
                                </div>
                                <div class="col-md-6">
                                    <label for=""> <?php echo e(__("In Arabic")); ?></label>
                                    <div class="card p-0 m-0" id="arabic_aboutuseditor"><?php echo $arabic_aboutus; ?> </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="card p-5">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h6 for=""><?php echo e(__("Terms & Conditions")); ?></h6>
                            <button id="updateTermsBtn" class="btn btn-outline-primary hidden"> <?php echo e(__("Save Changes")); ?></button>
                            <button class="btn btn-outline-success" type="button" data-toggle="collapse"
                                data-target="#terms_conditions" aria-expanded="false" aria-controls="terms_conditions">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32"
                                    height="32" fill="currentColor">
                                    <path d="M12 16L6 10H18L12 16Z"></path>
                                </svg></button>
                        </div>
                        <div class="collapse multi-collapse" id="terms_conditions">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for=""><?php echo e(__("In English")); ?></label>
                                    <div class="card" id="english_termseditor"><?php echo $english_terms; ?></div>
                                </div>
                                <div class="col-md-6">
                                    <label for=""> <?php echo e(__("In Arabic")); ?></label>
                                    <div class="card p-0 m-0" id="arabic_termseditor"><?php echo $arabic_terms; ?> </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="card p-5">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h6 for=""><?php echo e(__("Privacy Policy")); ?></h6>
                            <button id="updatePrivcyBtn" class="btn btn-outline-primary hidden"> <?php echo e(__("Save Changes")); ?></button>
                            <button class="btn btn-outline-success" type="button" data-toggle="collapse"
                                data-target="#privacy" aria-expanded="false" aria-controls="privacy">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32"
                                    height="32" fill="currentColor">
                                    <path d="M12 16L6 10H18L12 16Z"></path>
                                </svg></button>
                        </div>
                        <div class="collapse multi-collapse" id="privacy">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for=""><?php echo e(__("In English")); ?></label>
                                    <div class="card" id="english_privcyeditor"><?php echo $english_privacy; ?></div>
                                </div>
                                <div class="col-md-6">
                                    <label for=""> <?php echo e(__("In Arabic")); ?></label>
                                    <div class="card p-0 m-0" id="arabic_privcyeditor"><?php echo $arabic_privacy; ?> </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            const toolbarOptions = [
                [{
                    'header': [1, 2, 3, 4, 5, 6, false]
                }],
                [{
                    'header': 1
                }, {
                    'header': 2
                }], // custom button values
                [{
                    'list': 'ordered'
                }, {
                    'list': 'bullet'
                }],

                ['bold', 'italic', 'underline'],
                [{
                    'direction': 'rtl'
                }],
                [{
                    'align': []
                }],
                ['clean']
            ];

            const quill = new Quill('#arabic_termseditor', {
                theme: 'bubble',
                modules: {
                    toolbar: toolbarOptions
                }
            });
            const quill2 = new Quill('#english_termseditor', {
                theme: 'bubble',
                modules: {
                    toolbar: toolbarOptions
                }
            });
            const quill3 = new Quill('#arabic_aboutuseditor', {
                theme: 'bubble',
                modules: {
                    toolbar: toolbarOptions
                }
            });
            const quill4 = new Quill('#english_aboutuseditor', {
                theme: 'bubble',
                modules: {
                    toolbar: toolbarOptions
                }
            });
            const quill5 = new Quill('#arabic_privcyeditor', {
                theme: 'bubble',
                modules: {
                    toolbar: toolbarOptions
                }
            });
            const quill6 = new Quill('#english_privcyeditor', {
                theme: 'bubble',
                modules: {
                    toolbar: toolbarOptions
                }
            });

            quill.on('text-change', () => {
                $("#updateTermsBtn").show();
            });
            quill2.on('text-change', () => {
                $("#updateTermsBtn").show();
            });
            quill3.on('text-change', () => {
                $("#updateAboutUsBtn").show();
            });
            quill4.on('text-change', () => {
                $("#updateAboutUsBtn").show();
            });
            quill5.on('text-change', () => {
                $("#updatePrivcyBtn").show();
            });
            quill6.on('text-change', () => {
                $("#updatePrivcyBtn").show();
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views\pages\settings.blade.php ENDPATH**/ ?>