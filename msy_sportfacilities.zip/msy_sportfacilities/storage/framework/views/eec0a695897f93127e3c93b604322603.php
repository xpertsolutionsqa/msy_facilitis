

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="iq-top-navbar-<?php echo e(app()->getLocale()); ?>">
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex flex-wrap align-items-center justify-content-between breadcrumb-content">
                                    <h5><?php echo e(__('Logs')); ?></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">

                    </div>
                    <div class="col-md-4">
                        <input id="myInput" onkeyup="myFunction(1,[2,3,4,5]);" type="text"
                            placeholder="<?php echo e(__('Search')); ?>" class="form-control">
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card p-2">
                            <table id="myTable" class="table table-bordered  ">
                                <thead>
                                    <tr>
                                        <th>User Type</th>
                                        <th>User ID</th>
                                        <th>User Number</th>
                                        <th>User Name</th>
                                        <th>Query</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($log->user_type); ?></td>
                                            <td><?php echo e($log->user_id); ?></td>
                                            <td><?php echo e($log->user_number); ?></td>
                                            <td><?php echo e($log->user_name); ?></td>
                                            <td><?php echo e($log->query); ?></td>
                                            <td><?php echo e($log->created_at->format('Y-m-d H:i:s')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" class="text-center">No logs available</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <div class="p-3"  >
                                <?php echo e($logs->links('pagination.bootstrap-5')); ?>

                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views/pages/logs.blade.php ENDPATH**/ ?>