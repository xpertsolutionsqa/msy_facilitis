

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="iq-top-navbar-<?php echo e(app()->getLocale()); ?>">
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="content-page">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card blur-shadow">
                            <div class="card-body">
                                <div class="d-flex   align-items-center justify-content-between ">
                                    <div class="text-cetnter">
                                        <h5><?php echo e(__('Reports')); ?></h5>
                                    </div>

                                    <div class="d-flex align-items-center">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="FacilityFilter"><?php echo e(__('Facility')); ?> </label>
                                        <select class="form-control" id="ReportFacility">
                                            <option value=""><?php echo e(__('All Facilities')); ?> </option>
                                            <?php $__currentLoopData = \App\Models\Facility::where('status', '1')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e(app('request')->input('fa') == $item->number ? 'selected' : ''); ?>

                                                    value="<?php echo e($item->number); ?>"><?php echo e($item->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="FacilityFilter"><?php echo e(__('Bookings - Maintenance')); ?> </label>
                                        <select class="form-control  " id="ReportType">
                                            <option value=""><?php echo e(__('Both')); ?> </option>
                                            <option value="bookings"><?php echo e(__('Bookings')); ?> </option>
                                            <option value="maintenance"><?php echo e(__('Maintenance')); ?> </option>

                                        </select>
                                    </div>
                                    <div class="col-md-4 forBookings">
                                        <label for="booker"><?php echo e(__('Booked By')); ?> </label>
                                        <select class="form-control select2 " id="booker">
                                            <option value=""><?php echo e(__('All')); ?> </option>
                                            <?php $__currentLoopData = \App\Models\Client::where('status', '1')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="1|<?php echo e($client->number); ?>"><?php echo e($client->displayname); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = \App\Models\User::where('status', '1')->where('level', '1')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="2|<?php echo e($user->usernumber); ?>"><?php echo e($user->displayname); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                </div>
                                <div class="row pr-4 pl-4 pt-2">
                                    <div class="col-md-4">
                                        <label for=" "><?php echo e(__('From Date')); ?> </label>
                                        <input type="date" class="form-control" id="ReportFromDate">
                                    </div>
                                    <div class="col-md-4">
                                        <label for=" "><?php echo e(__('To Date')); ?> </label>
                                        <input type="date" class="form-control" id="ReportToDate">
                                    </div>
                                    <div class="col-md-4 forBookings">
                                        <label for=" "><?php echo e(__('Status')); ?> </label>
                                        <select class="form-control" id="ReportStatus">
                                            <option value=""><?php echo e(__('All')); ?> </option>
                                            <option value="1"><?php echo e(__('New')); ?> </option>
                                            <option value="2"><?php echo e(__('Div Manger Approval')); ?> </option>
                                            <option value="3"><?php echo e(__('Dep Manger Approval')); ?> </option>
                                            <option style="color: green;" value="4"><?php echo e(__('Approved')); ?> </option>
                                            <option style="color: red;" value="5"><?php echo e(__('Rejected')); ?> </option>
                                            <option style="color: rgb(128, 128, 52);" value="0">
                                                <?php echo e(__('Retreuned For Edit')); ?> </option>
                                            <option style="color: rgb(126, 24, 24);" value="6"><?php echo e(__('Canceled')); ?>

                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row p-3">
                                    <div class="col-md-12">
                                        <button class="btn btn-block btn-outline-success"
                                            id="GenerateReport"><?php echo e(__('Create')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="ReportResult" style="font-family: 'Times New Roman', Times, serif !important">
                    <div class="row p-1">
                        <div class="col-md-12">
                            <div class="card h-100  d-flex justify-content-center align-items-center">
                                <div class="text-center p-5">
                                    <h5 class="p-5"><?php echo e(__('Please Generate Report')); ?> </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views\pages\reports\index.blade.php ENDPATH**/ ?>