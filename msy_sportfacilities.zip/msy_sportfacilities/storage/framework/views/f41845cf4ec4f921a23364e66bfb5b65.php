<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form action="<?php echo e(route('testdes')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="">zone</label> <input type="text" name="zone">
        <label for="">street</label> <input type="text" name="street">
        <label for="">buliding</label> <input type="text" name="buliding">
        <button type="submit">Enter</button>
    </form>
</body>

</html>
<?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views\pages\testform.blade.php ENDPATH**/ ?>