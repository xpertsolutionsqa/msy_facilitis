<div class="modal fade bd-example-modal-lg" role="dialog" aria-modal="true" id="edit_user_model">
    <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header d-block text-center pb-3 border-bttom">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h3 class="modal-title"><?php echo e(__('Edit User')); ?> </h3>
            </div>
            <div class="modal-body">
                <?php if(isset($user)): ?>
                    <form action="<?php echo e(route('user.edit')); ?>" id="createAdminForm" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                        <input type="hidden" name="number" value="<?php echo e($user->usernumber); ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="" class="required-label"><?php echo e(__('Name')); ?></label>
                                <input type="text" class="form-control required" value="<?php echo e($user->displayname); ?>"
                                    name="displayname">
                            </div>
                            <div class="col-md-6">
                                <label for="" class="required-label"><?php echo e(__('User Name')); ?></label>
                                <input type="text" class="form-control required" value="<?php echo e($user->username); ?>"
                                    name="username">
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-md-6">
                                <label for="" class="required-label"><?php echo e(__('Email')); ?></label>
                                <input type="email" class="form-control required" value="<?php echo e($user->email); ?>"
                                    name="email">
                            </div>
                            <div class="col-md-6">
                                <label for="" class="required-label"><?php echo e(__('Phone')); ?></label>
                                <input type="text" class="form-control required" value="<?php echo e($user->phone); ?>"
                                    name="phone">
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-md-6">
                                <label for="" class="required-label"><?php echo e(__('Level')); ?></label>
                                <select name="level" class="form-control required" id="userEditLevel">
                                    <?php $__currentLoopData = \App\Models\UserLevel::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($user->level == $level->id ? 'selected' : ''); ?>

                                            value="<?php echo e($level->id); ?>">
                                            <?php echo e($level->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            
                            <div class="col-md-6" id="editclubselect"
                                style="display: <?php echo e($user->level == '3' ? 'unset' : 'none'); ?>">
                                <label for="" class="required-label"><?php echo e(__('Club')); ?></label>
                                <select name="club" id="userEditClub" class="form-control required">
                                    <?php $__currentLoopData = \App\Models\Club::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($user->club_id == $club->id ? 'selected' : ''); ?> value="<?php echo e($club->id); ?>"> <?php echo e($club->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                        </div>
                        <div class="p-1"></div>
                        <div class="row">
                            <div class="col-6">
                                <button type="button" class="btn btn-outline-danger btn-block" data-dismiss="modal"
                                    aria-label="Close"> <?php echo e(__('Cancel')); ?> </button>
                            </div>
                            <div class="col-6">

                                <button class="btn-block btn btn-outline-warning"
                                    type="submit"><?php echo e(__('Edit')); ?></button>
                            </div>
                        </div>


                    </form>
                <?php else: ?>
                    <form action="<?php echo e(route('client.edit')); ?> " method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_type" value="<?php echo e($client->type); ?>">
                        <input type="hidden" name="id" value="<?php echo e($client->id); ?>">
                        <input type="hidden" name="number" value="<?php echo e($client->number); ?>">


                        <div class="row">
                            <div class="col-md-12 card  ">
                                <label class="required-label" for=""><?php echo e(__('Booker Type')); ?></label>
                                <div class="row d-flex justify-content-start align-items-center p-2">

                                    <?php $__currentLoopData = \App\Models\UserType::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex">
                                            <input <?php echo e($client->type == $type->id ? 'checked' : ''); ?>

                                                id="<?php echo e($type->id); ?>" name="type"
                                                class="form-control   smallcheck" value="<?php echo e($type->id); ?>"
                                                type="radio"><span class="space">
                                                <?php echo e($type->getTranslation('title', app()->getlocale())); ?> </span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row p-3">
                            <div class="col-md-4">
                                <label for=""><?php echo e(__('Display Name')); ?></label>
                                <input name="displayname" class="form-control" value="<?php echo e($client->displayname); ?>">
                            </div>
                            <div class="col-md-4">
                                <label for=""><?php echo e(__('Email')); ?></label>
                                <input name="email" type="email" class="form-control"
                                    value="<?php echo e($client->email); ?>">
                            </div>
                            <div class="col-md-4">
                                <label for=""><?php echo e(__('Phone')); ?></label>
                                <input name="phone" class="form-control" value="<?php echo e($client->phone); ?>">
                            </div>
                        </div>





                        <div class="row">
                            <div class="col-6">
                                <button type="button" class="btn btn-outline-danger btn-block" data-dismiss="modal"
                                    aria-label="Close"> <?php echo e(__('Cancel')); ?> </button>
                            </div>
                            <div class="col-6">

                                <button class="btn-block btn btn-outline-warning"
                                    type="submit"><?php echo e(__('Update')); ?></button>
                            </div>
                        </div>


                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<script>
    var myModal = new bootstrap.Modal(document.getElementById('edit_user_model'), {});
    myModal.show();
</script>
<?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views/pages/users/edit.blade.php ENDPATH**/ ?>