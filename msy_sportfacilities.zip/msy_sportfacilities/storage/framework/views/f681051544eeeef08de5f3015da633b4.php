<style>
    table {
        border: 1px solid #f7f7f7 !important;
        border-radius: 5px !important;
    }

    th {
        word-wrap: break-word !important;
        font-size: 15px !important;
        padding: 3px !important;
        vertical-align: middle !important;
        background-color: #89173E !important;
        color: #fff !important;
    }
</style>
<div class="card">
    <div class="h-100">
        <div id="imageDiv" style="display: none">
            <div class="d-flex justify-content-center align-items-center p-3">
                <img style="height: 150px" src="<?php echo e(asset('assets/images/logo/msy_logo.png')); ?>" alt=""
                    srcset="">
            </div>
        </div>

        <div class="d-flex justify-content-between align-items-center p-3 ">
            <h4 class="p-5" style="line-height: 2"> <?php echo $title; ?></h4>
            <?php if(count($bookings) > 0 || count($maintenance)): ?>
                <button type="button" id="PrintReport" divname="ReportResult" fileName="MSY_REPORT_<?php echo e(now()); ?>"
                    class="btn btn-outline-primary">
                    <?php echo e(__('Save As PDF')); ?> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24"
                        height="24" fill="currentColor">
                        <path
                            d="M5 4H15V8H19V20H5V4ZM3.9985 2C3.44749 2 3 2.44405 3 2.9918V21.0082C3 21.5447 3.44476 22 3.9934 22H20.0066C20.5551 22 21 21.5489 21 20.9925L20.9997 7L16 2H3.9985ZM10.4999 7.5C10.4999 9.07749 10.0442 10.9373 9.27493 12.6534C8.50287 14.3757 7.46143 15.8502 6.37524 16.7191L7.55464 18.3321C10.4821 16.3804 13.7233 15.0421 16.8585 15.49L17.3162 13.5513C14.6435 12.6604 12.4999 9.98994 12.4999 7.5H10.4999ZM11.0999 13.4716C11.3673 12.8752 11.6042 12.2563 11.8037 11.6285C12.2753 12.3531 12.8553 13.0182 13.5101 13.5953C12.5283 13.7711 11.5665 14.0596 10.6352 14.4276C10.7999 14.1143 10.9551 13.7948 11.0999 13.4716Z">
                        </path>
                    </svg> </button>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="col-md-12 pr-3 pl-3">
                <?php if($showBookings): ?>
                    <div class="shadow p-3  ">
                        <div class="d-flex justify-content-between align-items-center p-3 ">
                            <h6><?php echo e(__('Bookings')); ?></h6>
                            <button type="button" class="btn btn-outline-success ExportTable"
                                tableid="reportBookingsTable" filename="MSY_BookingReport_<?php echo e(now()); ?>">
                                <?php echo e(__('Save As Excel')); ?> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                    width="24" height="24" fill="currentColor">
                                    <path
                                        d="M2.85858 2.87732L15.4293 1.0815C15.7027 1.04245 15.9559 1.2324 15.995 1.50577C15.9983 1.52919 16 1.55282 16 1.57648V22.4235C16 22.6996 15.7761 22.9235 15.5 22.9235C15.4763 22.9235 15.4527 22.9218 15.4293 22.9184L2.85858 21.1226C2.36593 21.0522 2 20.6303 2 20.1327V3.86727C2 3.36962 2.36593 2.9477 2.85858 2.87732ZM4 4.73457V19.2654L14 20.694V3.30599L4 4.73457ZM17 19H20V4.99997H17V2.99997H21C21.5523 2.99997 22 3.44769 22 3.99997V20C22 20.5523 21.5523 21 21 21H17V19ZM10.2 12L13 16H10.6L9 13.7143L7.39999 16H5L7.8 12L5 7.99997H7.39999L9 10.2857L10.6 7.99997H13L10.2 12Z">
                                    </path>
                                </svg> </button>
                        </div>
                        <?php if(count($bookings) == 0): ?>
                            <div class="text-center p-5 m-5">
                                <b> <?php echo e(__('No Bookings Founded')); ?> </b>
                            </div>
                        <?php else: ?>
                            <div class="card-body p-2">
                                <table id="reportBookingsTable" class="table rounded">
                                    <thead>
                                        <th>#</th>
                                        <th style=";"><?php echo e(__('Request Date')); ?></th>
                                        <th><?php echo e(__('Number')); ?></th>
                                        <?php if(!isset($user) && !isset($client)): ?>
                                            <th><?php echo e(__('Booker Name')); ?></th>
                                        <?php endif; ?>
                                        <th><?php echo e(__('Event')); ?></th>
                                        <th><?php echo e(__('Contact Information')); ?></th>
                                        <th><?php echo e(__('From Date')); ?></th>
                                        <th><?php echo e(__('To Date')); ?></th>
                                        <th><?php echo e(__('Requierd Days No')); ?></th>
                                        <th><?php echo e(__('Expected Participants No')); ?></th>

                                        <th><?php echo e(__('Status')); ?></th>
                                        <th></th>

                                        <th> </th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <td><?php echo e($i + 1); ?></td>
                                                <td><?php echo e($booking->created_at); ?></td>
                                                <td><?php echo e($booking->number); ?></td>
                                                <?php if(!isset($user) && !isset($client)): ?>
                                                    <td><?php
                                                        $req = $booking->UserOrClient();

                                                    ?>
                                                        <?php if($req): ?>
                                                            <?php echo e($req->displayname); ?>

                                                        <?php else: ?>
                                                            <p><?php echo e(__('Sorry Couldnt get User Data')); ?></small>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                                <td><?php echo e($booking->event_name); ?></td>
                                                <td><?php echo e($booking->cname); ?> <br> <?php echo e($booking->cphone); ?> <br>
                                                    <?php echo e($booking->cemail); ?> </td>
                                                <td><?php echo e($booking->start_date . ' ' . $booking->start_time); ?>

                                                </td>
                                                <td><?php echo e($booking->end_date . ' ' . $booking->end_time); ?>

                                                </td>
                                                <td><?php echo e($booking->days); ?></td>
                                                <td><?php echo e($booking->particpations); ?></td>
                                                <td> <?php echo $booking->fullhtmlstatus; ?>

                                                </td>



                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>


                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <br>
                <?php if($showMaintenance): ?>
                    <div class="shadow p-3  ">
                        <div class="d-flex justify-content-between align-items-center p-3 ">
                            <h6><?php echo e(__('Maintenance')); ?></h6>
                            <button type="button"  class="btn btn-outline-success ExportTable"
                                tableid="reportMinTable" filename="MSY_MaintenanceReport_<?php echo e(now()); ?>">
                                <?php echo e(__('Save As Excel')); ?> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                    width="24" height="24" fill="currentColor">
                                    <path
                                        d="M2.85858 2.87732L15.4293 1.0815C15.7027 1.04245 15.9559 1.2324 15.995 1.50577C15.9983 1.52919 16 1.55282 16 1.57648V22.4235C16 22.6996 15.7761 22.9235 15.5 22.9235C15.4763 22.9235 15.4527 22.9218 15.4293 22.9184L2.85858 21.1226C2.36593 21.0522 2 20.6303 2 20.1327V3.86727C2 3.36962 2.36593 2.9477 2.85858 2.87732ZM4 4.73457V19.2654L14 20.694V3.30599L4 4.73457ZM17 19H20V4.99997H17V2.99997H21C21.5523 2.99997 22 3.44769 22 3.99997V20C22 20.5523 21.5523 21 21 21H17V19ZM10.2 12L13 16H10.6L9 13.7143L7.39999 16H5L7.8 12L5 7.99997H7.39999L9 10.2857L10.6 7.99997H13L10.2 12Z">
                                    </path>
                                </svg> </button>
                        </div>

                        <?php if(count($maintenance) == 0): ?>
                            <div class="text-center p-5 m-5">
                                <b> <?php echo e(__('No Maintenance Founded')); ?> </b>
                            </div>
                        <?php else: ?>
                            <div class="card-body p-2">
                                <table id="reportMinTable" class="table rounded">
                                    <thead>
                                        <th>#</th>
                                        <th><?php echo e(__('Created At')); ?></th>
                                        <th><?php echo e(__('Number')); ?></th>
                                        <?php if(!isset($facility)): ?>
                                            <th><?php echo e(__('Facility')); ?></th>
                                        <?php endif; ?>
                                        <th><?php echo e(__('From Date')); ?></th>
                                        <th><?php echo e(__('To Date')); ?></th>
                                        <th><?php echo e(__('Days')); ?></th>
                                        <th><?php echo e(__('Maintenance Agenda')); ?></th>
                                        <th><?php echo e(__('Maintenance Team')); ?></th>

                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $maintenance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $min): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i + 1); ?></td>
                                                <td><?php echo e($min->created_at); ?></td>
                                                <td><?php echo e($min->number); ?></td>
                                                <?php if(!isset($facility)): ?>
                                                    <td><?php echo e($min->facility->title); ?></td>
                                                <?php endif; ?>
                                                <td><?php echo e($min->startDate); ?></td>
                                                <td><?php echo e($min->endDate); ?> </td>
                                                <td><?php echo e($min->days); ?> </td>
                                                <td><?php echo e($min->description); ?> </td>
                                                <td><?php echo e($min->team); ?> </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views\pages\reports\result.blade.php ENDPATH**/ ?>