<footer class="iq-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6">
              
            </div>
            <div class="col-lg-6 text-right">
                <a href="https://www.msy.gov.qa/" class=""><?php echo e(__("MSY")); ?></a>
                <span class="mr-1">
                    <script>
                        document.write(new Date().getFullYear())
                    </script>©
                </span> 
            </div>
        </div>
    </div>
</footer><?php /**PATH E:\projects\Laravel\msy_sportfacilities\resources\views/layouts/footer.blade.php ENDPATH**/ ?>